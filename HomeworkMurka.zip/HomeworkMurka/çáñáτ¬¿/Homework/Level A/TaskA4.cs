﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework
{
    // Задача А4.
    // Кол-во стингеров: ⅓🔹
    //
    // Написать функцию ListOfSums(List<int> list), которая получает на вход
    // список чисел и возвращает только те, которые равны сумме всех
    // предшествующих элементов этого списка.
    //
    // Пример:
    // ListOfSums([2,3,5,6]) ==> [5] -> 5 = 2 + 3;
    // ListOfSums([10,20,30,60,-120,0]) ==> [30,60,0].
    public static class TaskA4
    {
        public static List<int> ListOfSums(List<int> list)
        {
            // Здесь необходимо написать код.
            int score = list.Count;
            int last = 0;
            int now = 0;
            int ok = 0;
            int[] mas = new int[score];
            for (int i = 0; i < score; i++)
            {
                mas[i] = list[i];
            }
            List<int> list2 = new List<int>();   
            last = mas[0];
            /*
             for (int i = 1; i < score; i++)
             {
                 for (int j = i + 1; j < score; j++)
                 {
                      for (int g = j + 1; g < score; g++)
                      {
                          if (last + mas[i] + mas[j] == mas[g])
                          {
                              list2.Add(mas[g]);
                          }
                      }
                  }
              }
             */
            /*
             for (int i = 0; i < score; i++)
             {
                 for (int j = i + 1; j < score; j++)
                 {
                     for (int g = j + 1; g < score; g++)
                     {
                         if (mas[i] + mas[j] == mas[g])
                         {
                             list2.Add(mas[g]);
                         }
                     }
                 }
             }
             */
            
             for (int i = 0; i < score; i++)
             {
                 for (int j = i + 1; j < score; j++)
                 {
                     for (int g = j + 1; g < score; g++)
                     {
                         if (mas[i] + mas[j] == mas[g])
                         {
                             list2.Add(mas[g]);
                         }
                         now = mas[0];
                         ok = mas[1];
                         for (int a = g + 1; a < score; a++)
                         {

                             last = mas[i] + mas[j] + mas[g];
                             if (last == mas[a])
                             {
                                 list2.Add(mas[a]);
                             }
                             else if (now + ok + last == mas[a])
                             {
                                 list2.Add(mas[a]);
                             }
                         }
                     }
                 }
             }
            


            return list2;
        }
    }
}
